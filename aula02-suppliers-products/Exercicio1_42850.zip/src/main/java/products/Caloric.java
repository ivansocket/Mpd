package products;

/**
 * Caloric interface
 */
public interface Caloric {
    public int getCalories();
}
